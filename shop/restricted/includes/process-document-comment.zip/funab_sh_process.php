 <?php
 
 include("config/DB_config.php");

/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
$emailing = "";
//$emailing = "";
 
 if(isset($_POST['validate']))
 {
 
 if(isset($_SESSION['email']))
 {
$emailing  = $_SESSION['email'];
 }

//SELECT `id`, `name`, `phone`, `email`, `position`, `status`, `created_date`, `registeredby` FROM `stake_holder` WHERE 1
 
$name= $_POST['name'];
	 $phone= $_POST['phone'];
	 $email= $_POST['email'];
	$status  = $_POST['status'];
	$signature  = $_POST['signature'];
	$mda  = $_POST['registry'];

	 $position  = $_POST['position'];
	 $account_number = "OGSG".rand(10, 99).rand(11, 89).rand(10, 99);
	 
 
	 
	 $phone_retrieve = $myName->showName($conn, "SELECT `phone` FROM `user_unit` WHERE  (`account_number` = '$account_number'  OR `phone` = '$phone' OR `email` = '$email') AND `ministry` = '$mda' "); 
	 if($phone_retrieve != "")
	 {
		echo'<a href="#" class="btn btn-danger btn-lg">Information in the  database already...  <br />Please check and try again later.</a><br />';
 
		 
	 }
	 else
	 {
 
  $extract_user = mysqli_query($conn, "SELECT * FROM `stake_holder` WHERE  (`name` = '$name' OR `phone` = '$phone' OR `email` = '$email' OR `account_number` = '$account_number') AND  `mda` = '$mda'") or die(mysqli_error($conn));
		$count = mysqli_num_rows($extract_user);
		 if ($count > 0) {
	 	 
	echo'<a href="#" class="btn btn-danger btn-lg">Information in the  database already.  <br />Please check and try again later.</a><br />';

		  
	
 
		 }else
		 {
 
  $password = rand(3455, 827365345);					
$uuid = uniqid('', true);

$salt = sha1(rand());
        $salt = substr($salt, 0, 4);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
         
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; 
 	 
$sql = 	 "INSERT INTO `stake_holder`(`name`, `phone`, `email`, `position`, `status`, `created_date`, `registeredby`, `unique_id`, `encrypted_password`, `salt`, `irrelivant`, `username`, `account_number`, `signature`, `mda`) VALUES
('$name', '$phone', '$email', '$position', '$status', '$datetime', '$emailing', '$uuid' ,'$encrypted_password','$salt', '$password', '$phone', '$account_number', '$signature', '$mda')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
 
	if ($process) {
		
		
		 
 $sql = 	 "INSERT INTO `user_unit`(`usertype`,`name`, `account_number`, `phone`, `email`, `address`, `created_date`, `registeredby`, `status`, `unique_id`, `encrypted_password`, `salt`, `irrelivant`, `ministry`, `signature`) VALUES
('1','$name', '$account_number', '$phone', '$email', '-', '$datetime', '$emailing',1, '$uuid' ,'$encrypted_password','$salt', '$password', '$mda', '$signature')";
		
		
		$process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
  echo '<div class="btn btn-success btn-lg">Information Submitted Successfully.</a></div><br />'; 	
  
 
  	 $Phone = $phone;
		$link = "";
		
		if($signature == 1)
		{
$link = "Your Signature is required.
http://".$_SERVER['HTTP_HOST']."/oysg/signature-page.php";
		}
 
$message = "Welcome to ". $inst_name." ".$name."! 
Username:".$phone.".
Password:".$password.".
".$link."
Thank You.";

  
  	 $Sending = new SendingSMS(); 
  							 
							 $Sending->smsAPI($Phone,"docprodev",$message);
		
		/* 
                          
                          
                          
                      
                          <option value = "grant">Grant Request </option>
                          <option value = "returned">Returned File </option>*/
		
		
	 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','delete', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
	 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','activate', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
			 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','deactivate', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
					 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','transfer', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
					 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','comment', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
					 $sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','view', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));	
		
$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','download', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
		$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','approve', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
		
		$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','grant', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
			$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','returned', '1', '$datetime', '$emailing')";
 
 
		$process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
		
		$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','share', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
		
		
		
		$sql = 	 "INSERT INTO `privilege`(`account_number`, `rights`, `status`, `created_date`, `registeredby`) VALUES
('$account_number','update', '1', '$datetime', '$emailing')";
 
 $process = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		
  
   
} else {
  // echo "Error: " . $sql . "<br>" . $conn->error;
    $error="Not Inserted,Some Problem occured.";
echo'<a href="#"class="btn btn-danger btn-lg">Information Not Submitted Successfully.  <br />Please try again later.</a><br />';  

}

 
	}	 
 
		
 
 }
 		 
 }

 
$conn->close();
	
 
?>

 